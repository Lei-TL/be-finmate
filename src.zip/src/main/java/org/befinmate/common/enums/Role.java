package org.befinmate.common.enums;

public enum Role {

    USER,
    ADMIN

}
