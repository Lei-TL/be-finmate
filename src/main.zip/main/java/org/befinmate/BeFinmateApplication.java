package org.befinmate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeFinmateApplication {

	public static void main(String[] args) {
		SpringApplication.run(BeFinmateApplication.class, args);
	}

}
