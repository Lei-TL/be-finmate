package org.befinmate.entity;

public class Friend {
}
