package org.befinmate.dto.request;

public class SyncRequest {
}
