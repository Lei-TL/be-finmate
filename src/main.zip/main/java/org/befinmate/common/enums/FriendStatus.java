package org.befinmate.common.enums;

public enum FriendStatus {

    PENDING,
    ACCEPTED,
    REJECTED,
    BLOCKED
}
