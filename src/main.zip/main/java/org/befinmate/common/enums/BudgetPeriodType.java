package org.befinmate.common.enums;

public enum BudgetPeriodType {
    MONTHLY,
    WEEKLY,
    YEARLY,
    CUSTOM
}
