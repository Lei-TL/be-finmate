package org.befinmate.common.enums;

public enum TransactionType {

    INCOME,
    EXPENSE,
    TRANSFER

}
